package week5;

import java.util.Scanner;

public class principal {

	public static void main(String[] args) 
	{
		System.out.println("     		      WELCOME ON CODING IS FUN");
		System.out.println("\nA l'aide de ce menu, choissez la tache que vous soulez effectuer");
		System.out.println("1-Tester la primalite d'un nombre");
		System.out.println("2-Calculer le factoriel d'un nombre");
		System.out.println("3-Calculer le PGCD de plusieurs nombres");
		System.out.println("4-Calculer le PPMC de plusieurs nombres");
		System.out.println("5-Rechercher un element dans une liste par la methode dichotomique");
		System.out.println("6-Empiler et depiler une liste");
		
		int choix;
		
		Scanner choice= new Scanner(System.in);
		choix=choice.nextInt();
		while(choix!=1 && choix!=2 &&choix!=3 &&choix!=4 &&choix!=5 &&choix!=6)
		{
			System.out.println("Aucune option ne correspond a votre saisie, reessayez");
			choix=choice.nextInt();
		}
		
		switch (choix)
		{
		case 1:
			function.primalite();
			break;
		case 2:
			function.factoriel();
			break;
		case 3:
			function.pgcd();
			break;
		case 4:
			function.ppmc();
			break;
		case 5:
			function.dichotomic();
			break;
		case 6:
			function.pile();
			break;
		}
	}
}
