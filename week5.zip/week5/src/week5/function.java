package week5;

import java.util.Scanner;
import java.util.Stack;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class function
{

	public static void primalite()
	{
		System.out.println("Vous avez choisi de tester la primalite d'un nombre");
		System.out.println("\nSaisissez le nombre");
		
		int nombre;
		Scanner number=new Scanner(System.in);
		nombre=number.nextInt();
		
		boolean premier=false;
		if(nombre==1)
			premier=false;
		else if(nombre%2==0 && nombre!=2)//pour les nombres premiers differents de 2
			premier=false;
		
		else if((nombre%2)!=0)//pour les nombres impairs
		{
			int tab[]=new int [nombre-2];
			for(int i=0; i<tab.length-2;i++)
			{
				tab[i]=i+2;
				if((nombre%tab[i])==0)
				{
					i=tab.length-1;
					premier=false;
				}
				else
					premier=true;
			}
		}
		else if(nombre==2)
			premier=true;
		
		if(premier)
			System.out.println(+nombre+ " est un nombre premier");
		else
			System.out.println(+nombre+ " n'est pas un nombre premier");
	}
	
	public static void factoriel()
	{
		System.out.println("Vous avez choisi de calculer le factoriel");
		System.out.println("\nSaisissez le nombre");
		
		int nombre;
		Scanner number=new Scanner(System.in);
		nombre=number.nextInt();
		
		int factoriel=1;
		for(int i=1; i<=nombre;i++)
		{
			factoriel*=i;
		}
		System.out.println("Le factoriel de "+nombre+ " est "+factoriel);
	}
	
	public static void inserer_tab(int tab[],int n)
	{
		for (int i=0; i<tab.length; i++)
		{
			Scanner element=new Scanner(System.in);
			tab[i]=element.nextInt();
		}
	}
	
	public static void trier_tab(int tab[])
	{
		for(int i=0; i<tab.length-1;i++)
		{
			for(int j=0;j<tab.length-1;j++)
			{
				if(tab[j+1]<=tab[j])
				{
					int temp =tab[j];
					tab[j]=tab[j+1];
					tab[j+1]=temp;
				}			
			}
		}	
	}
	
	public static void ppmc()
	{
		System.out.println("Vous avez choisi de trouver le PPMC de plusieurs entiers");
		System.out.println("De combien de nombres voulez vous avoir le PPMC?");
		Scanner qty=new Scanner(System.in);
		int qte=qty.nextInt();
		while(qte<2)
		{
			System.out.println("Entrez une quantite de nombres superieur a 2");
			qte=qty.nextInt();
		}
		int tab[]=new int [qte];
		System.out.println("Saisissez les nombres");
		function.inserer_tab(tab, qte);
		int ppmc=1;
		for (int i=0; i<tab.length;i++)
		{
			function.trier_tab(tab);
			
			int min=tab[i];			
			for(int j=0;j<tab.length; j++)
			{
				if (tab[j]%min==0)
				{
						tab[j]=tab[j]/min;
				}
			}
			ppmc=min*ppmc;
			
		}
		System.out.println("Le PPMC des nombres est "+ppmc);
	}
	
	public static void pgcd()
	{
		System.out.println("Vous avez choisi de trouver le PGCD de plusieurs entiers");
		System.out.println("De combien de nombres voulez vous avoir le PGCD?");
		Scanner qty=new Scanner(System.in);
		int qte=qty.nextInt();
		while(qte<2)
		{
			System.out.println("Entrez une quantite de nombres superieur a 2");
			qte=qty.nextInt();
		}
		int tab[]=new int [qte];
		System.out.println("Saisissez les nombres");
		function.inserer_tab(tab, qte);
		function.trier_tab(tab);
		int max=tab[tab.length-1];
		int diviseur[]=new int [max];
		int temp=0;
		for(int i=1; i<=max;i++)
		{
			for(int j=0; j<qte;j++)
			{
				if(tab[j]%i==0)
					temp++;
			}
				if(temp==qte)
					diviseur[i]=i;
				temp=0;
		}
		function.trier_tab(diviseur);
		int max2=diviseur[diviseur.length-1];
		System.out.println("Le PGCD des nombres est "+max2);
	}
	
	public static void dichotomic_search(int valeur, int tab[])
	{
		trier_tab(tab);
		int debut, milieu, fin;
		boolean exist=false;
		debut=0;
		fin=tab.length;
		while(exist==false && debut<=fin)
		{
			milieu=(int)((debut+fin)/2);
			if(tab[milieu]==valeur)
			{
				exist=true;
			}
			else if(valeur>tab[milieu])
			{
				debut=milieu+1;
			}
			else
			{
				fin=milieu-1;
			}
		}
		if(exist) {
			System.out.println("La valeur existe dans le tableau");}
		else {
			System.out.println("La valeur n'est pas dans le tableau");}
	}
	
	public static void dichotomic()
	{
		System.out.println("Vous avez choisi de rechercher un element dans une liste");
		System.out.println("Remplissez votre liste");
	      List<Integer> mylist = new ArrayList<>();	     
	      Scanner element= new Scanner(System.in);
	      mylist.add(element.nextInt());
	      boolean keepon=true;
	      while(keepon)
	      {
	    	  System.out.println("Pressez 1 pour continuer a ajouter dans la liste et n'importe quoi pour y mettre fin");
		      Scanner choix= new Scanner (System.in);
		      int choice= choix.nextInt();
		     
		      if(choice==1)
		      {
		    	 keepon=true;
		    	 System.out.println("Inserez la nouvelle valeur");
		    	 mylist.add(element.nextInt());
		      }
		      else
		      {
		    	  keepon=false;
		    	  System.out.println("Fin de la liste");
		    	  System.out.println("Voici les elements de la liste: "+mylist);
		      }
	      }
	      
	      int[] tab = new int[mylist.size()];
	        for(int i = 0; i < mylist.size(); i++) 
	            tab[i] = mylist.get(i);
	        System.out.println("Quelle valeur recherchez-vous?");
	        Scanner value=new Scanner(System.in);
	        int valeur=value.nextInt();
	        function.dichotomic_search(valeur, tab);
	}
	
	public static void pile()
	{
		Stack mypile = new Stack();
		System.out.println("Vous avez choisi d'empiler ou de depiler");
		System.out.print("Quelle est la taille de votre pile? ");
		Scanner taille=new Scanner(System.in);
		int number = taille.nextInt();
		while(number<1)
		{
			System.out.println("La taille doit etre plus grande, reessayez");
			number = taille.nextInt();
		}
	    int[] array = new int[number];

		System.out.println("Remplissez votre pile");
		Scanner valeur=new Scanner(System.in);
	      for(int i = 0; i < array.length; i++)
	      {
	    	  int value = valeur.nextInt();              
	          mypile.push(value);
	      }
	      System.out.println("Voici votre pile" +mypile);
	      
	      boolean keepon=true;
	      while(keepon)
	      {
	    	  System.out.println("Pressez 1 pour depiler et 0 pour continuer a empiler et n'importe quoi pour la laisser ainsi");
		      int value=valeur.nextInt();
		      if (value==1)
		      {
		    	  keepon=true;
		    	  System.out.println("De combien voulez vous depiler votre pile?");
		    	  value=valeur.nextInt();
		    	  while(value>mypile.size())
		    	  {
		    		  System.out.println("Votre pile contient moins de " +value+ " elements");
		    		  value=valeur.nextInt();
		    	  }
		    	  for(int i = 0; i < value; i++)
			      {             
			          mypile.pop();
			      }
		    	  System.out.println("Voici votre nouvelle pile" +mypile);
		      }
		      else if(value==0){
		    	  {
		    		  keepon=true;
		    		  System.out.println("Ajoutez ce que vous voulez");
			    	 
				    	  value = valeur.nextInt();              
				          mypile.push(value);
//				     
			    	  System.out.println("Voici votre nouvelle pile" +mypile);
		    	  }
		      }
		      else
		    	  keepon=false;
	      }       
	     	     
	}
}


























